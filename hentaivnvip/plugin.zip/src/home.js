load('config.js');
function execute() {
    return Response.success([
        { title: "Cập Nhật", input: BASE_URL + "/truyen-hentai/", script: "gen.js" },
        { title: "Oneshot", input: BASE_URL + "/the-loai/oneshot/", script: "gen.js" },
        { title: "Không Che", input: BASE_URL + "/the-loai/khong-che/", script: "gen.js" },
        { title: "Manhwa", input: BASE_URL + "/the-loai/manhwa/", script: "gen.js" },
    ]);
}