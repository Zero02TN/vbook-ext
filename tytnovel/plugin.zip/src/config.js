let BASE_URL = "https://tytnovel.xyz";
let BASE_HOST = "https://api.noveltyt.xyz";


try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}