let BASE_URL = "https://tytnovel.xyz";
let BASE_HOST = "https://api.noveltyt.xyz";
let BASE_TOKEN = "1b47dd5691777623d05e50f66c46720b95351c4b9c7d2e2728c7d08ccef2d875";
let BASE_USER = "66d95cf231c59f350f798376";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}