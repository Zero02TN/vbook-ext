function execute() {
    return Response.success([
        {title: "Truyện mới", input: "https://atruyen.net/_next/data/RJ--yBs67-Ym_ec4fc0iw/danh-muc/truyen-moi.json?directory=truyen-moi", script: "gen.js"},
    ]);
}