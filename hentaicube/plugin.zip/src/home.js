function execute() {
    return Response.success([
        {title: "Cập nhật", input: "https://hentaicube.xyz", script: "gen.js"},
    ]);
}