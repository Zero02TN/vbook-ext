let BASE_URL = 'https://monkeyd.com.vn';

try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}