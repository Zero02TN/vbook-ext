function execute(url) {
    let response = fetch(url)
    if(response.ok){
        let doc = response.html()
        doc.select('a#affLayer').remove();
        doc.select('.signature').remove();
        let content = doc.select('.affActive p').html()
            .replace(/\n/gi, "<br>")
            .replace(/(\<br[\s]*\/?\>[\s]*)+/g, '<br>');
        return Response.success(content);
    }
    return null;
}