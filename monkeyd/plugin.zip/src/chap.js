function execute(url) {
    let response = fetch(url)
    if(response.ok){
        let doc = response.html()
        doc.select('.affClick').remove();
        doc.select('a#affLayer').remove();
        doc.select('.signature').remove();
        let content = doc.select('.content-container p').html()
            .replace(/\n/gi, "<br>")
            .replace(/(\<br[\s]*\/?\>[\s]*)+/g, '<br>')
            .replace(/\b((?:[\u00C0-\u1EF9a-zA-Z]{1}\.){2,}[\u00C0-\u1EF9a-zA-Z]{1})\b/g, function(s) {
                return s.replace(/\./g, '');
            });
        return Response.success(content);
    }
    return null;
}
