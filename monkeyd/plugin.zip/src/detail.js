load('config.js');

function execute(url) {
    const doc = fetch(url).html();

    // genres như trước
    let genres = [];
    doc.select('.col-sm-9 a').forEach(e => {
        genres.push({
            title:  e.text(),
            input:  e.attr('href'),
            script: "source.js"
        });
    });

    // --- BẮT ĐẦU LẤY THÔNG TIN CHO DETAIL ---
    // Team
    const team    = doc.select("dt:contains(Team) + dd a").text().trim();
    // Tác giả
    const tacGia  = doc.select("dt:contains(Tác giả) + dd").text().trim();
    // Lượt xem
    const luotXem = doc.select("dt:contains(Lượt xem) + dd").text().trim();
    // Yêu thích
    const yeuThich = doc.select("dt:contains(Yêu thích) + dd").text().trim();
    // Lượt theo dõi
    const luotTheoDoi = doc.select("dt:contains(Lượt theo dõi) + dd").text().trim();
    // Trạng thái
    const trangThai = doc.select("dt:contains(Trạng thái) + dd").text().trim();
    // Cập nhật
    const capNhat = doc.select("dt:contains(Cập nhật) + dd").text().trim();
    // Loại
    const loai    = doc.select("dt:contains(Loại) + dd span").text().trim();

    const detail = [
        `Team: ${team}`,
        `Tác giả: ${tacGia}`,
        `Lượt xem: ${luotXem}`,
        `Yêu thích: ${yeuThich}`,
        `Lượt theo dõi: ${luotTheoDoi}`,
        `Trạng thái: ${trangThai}`,
        `Cập nhật: ${capNhat}`,
        `Loại: ${loai}`
    ].join('<br>');
    // --- KẾT THÚC PHẦN DETAIL ---

    return Response.success({
        name:        doc.select("h1").text(),
        cover:       doc.select("meta[property='og:image']").first().attr('content'),
        description: doc.select(".ql-editor").text(),
        author:      tacGia,      // hoặc bạn vẫn dùng selector cũ nếu muốn
        detail:      detail,
        genres:      genres,
        ongoing:     doc.select('.row .col-sm-9').text().includes('Đang phát hành'),
        host:        BASE_URL
    });
}
