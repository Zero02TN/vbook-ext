function execute() {
    return Response.success([
        {title: "Nam Sinh", input: "https://hotruyen1.com/nam-sinh", script: "gen.js"}
    ]);
}