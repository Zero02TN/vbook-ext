let BASE_URL = 'https://sayhentai.pro';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}